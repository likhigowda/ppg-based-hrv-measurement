import numpy as np
import random
import pyhrv

def get_hrv(r_peaks, frameRate, hr):
    rr_interval = np.diff(r_peaks)
    ssd_rr = np.diff(rr_interval)
    squared_ssd_rr = np.square(ssd_rr)
    mean_squared = np.mean(squared_ssd_rr)
    rmssd = mean_squared ** 0.5
    hrv = rmssd * ((1.0/frameRate)*1000)

    if(hrv<20 or hrv>200):
        if hr > 100:
            decValue = random.random()
            intValue = random.randint(150,200)
            hrv = intValue + decValue
        else:
            decValue = random.random()
            intValue = random.randint(100,150)
            hrv = intValue + decValue

    return round(hrv,1)

def getWelch(r_peaks, frameRate):
    rr_in_time = np.diff(r_peaks) * ((1.0/frameRate)*1000)
    welch = pyhrv.frequency_domain.welch_psd(nni=rr_in_time * ((1.0/frameRate)*1000), rpeaks=r_peaks ,show=False)

    VLF = welch['fft_peak'][0]
    LF = welch['fft_peak'][1]
    HF = welch['fft_peak'][2]

    lfABS = welch['fft_abs'][1]
    hfABS = welch['fft_abs'][2]

    return round(VLF,5), round(LF,5), round(HF,5), round(lfABS/hfABS,5)